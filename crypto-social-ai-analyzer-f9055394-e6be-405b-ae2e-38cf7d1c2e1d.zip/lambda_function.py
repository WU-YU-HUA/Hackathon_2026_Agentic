import json
import time
import random
import boto3
from botocore.config import Config
from botocore.exceptions import ClientError

# 設定較長的 timeout（Claude Opus 回應可能較慢）
config = Config(
    read_timeout=300,
    connect_timeout=10,
    retries={'max_attempts': 3}
)

REGION = "us-west-2"
bedrock = boto3.client('bedrock-runtime', region_name=REGION, config=config)

# Claude Opus 4.5 Cross-region Inference Profile ID
MODEL_ID = "us.anthropic.claude-opus-4-5-20251101-v1:0"

# 最多帶入 prompt 的 Fear & Greed 歷史筆數
MAX_FNG_POINTS = 30


def lambda_handler(event, context):
    """
    Fear & Greed Index + 社群情緒（community sentiment）→ AI 產出 buy/hold/sell 報告
    """
    # 除錯用：印出原始 event，方便追蹤 Program A 傳來的實際結構
    try:
        print(f"[DEBUG] Raw event: {json.dumps(event, ensure_ascii=False)[:3000]}")
    except Exception:
        print(f"[DEBUG] Raw event (repr): {repr(event)[:3000]}")

    try:
        fng_data, community_sentiment, symbol = parse_input(event)

        if not fng_data and not community_sentiment:
            print("[ERROR] Failed to parse fear_and_greed / community_sentiment from event.")
            return error_response("No fear_and_greed or community_sentiment data provided or failed to parse input.")

        print(f"Processing sentiment analysis for symbol: {symbol} "
              f"(fng points: {len(fng_data)}, has_community: {bool(community_sentiment)})")

        prompt = build_prompt(fng_data, community_sentiment, symbol)
        ai_response = call_bedrock(prompt)
        analysis = parse_ai_response(ai_response)

        analysis['metadata'] = {
            'model': MODEL_ID,
            'symbol': symbol,
            'fng_points_analyzed': len(fng_data),
            'has_community_sentiment': bool(community_sentiment)
        }

        return success_response(analysis)

    except Exception as e:
        print(f"Error: {str(e)}")
        import traceback
        traceback.print_exc()
        return error_response(str(e))


def parse_input(event):
    """
    解析多種傳入格式，確保穩健解包 (Unpack)
    回傳: (fng_data: list, community_sentiment: dict|None, symbol: str)
    """
    symbol = "UNKNOWN"

    # ===== 情況 1: JSON 字串 =====
    if isinstance(event, str):
        print("Input format: JSON string")
        try:
            event = json.loads(event)
        except json.JSONDecodeError:
            return [], None, symbol

    if not isinstance(event, dict):
        print(f"Unknown input format: {type(event)}")
        return [], None, symbol

    # ===== 情況 2: 完整的 Lambda 回應格式 ({statusCode: 200, body: ...}) =====
    if 'body' in event and ('statusCode' in event or 'headers' in event):
        print("Input format: Lambda response wrapper with body")
        body = event['body']
        if isinstance(body, str):
            try:
                body = json.loads(body)
            except json.JSONDecodeError:
                return [], None, symbol
        event = body

    if not isinstance(event, dict):
        return [], None, symbol

    # ===============================================================
    # 🌟 專門接住來自 Program A 的包裝格式 (極高容錯)
    # Program A 可能用不同的 key 名稱包這份資料，例如：
    #   {"symbol":..., "sentiment_data": {...}}
    #   {"symbol":..., "social_data": {...}}
    #   {"symbol":..., "fear_and_greed_data": {...}}
    # 這些 wrapper key 底下預期直接是 {"fear_and_greed":[...], "community_sentiment":{...}}
    # ===============================================================
    WRAPPER_KEYS = ('sentiment_data', 'social_data', 'fear_and_greed_data', 'fng_data')
    for wk in WRAPPER_KEYS:
        if wk in event and isinstance(event[wk], dict):
            print(f"Input format: wrapped under '{wk}' from Program A")
            symbol = event.get('symbol', symbol)
            event = event[wk]
            break

    # 到這裡 event 應該長得像:
    # {"symbol": "BTC", "fear_and_greed": [...], "community_sentiment": {...}}
    symbol = event.get('symbol', symbol)

    fng_data = []
    raw_fng = event.get('fear_and_greed') or event.get('fear_and_greed_index') or event.get('fng') or []
    if isinstance(raw_fng, list):
        fng_data = [x for x in raw_fng if isinstance(x, dict)]
        # 依 timestamp 由新到舊排序（若有 timestamp 欄位）
        try:
            fng_data.sort(key=lambda x: x.get('timestamp', 0), reverse=True)
        except Exception:
            pass

    community_sentiment = event.get('community_sentiment')
    if not isinstance(community_sentiment, dict):
        community_sentiment = None
        # 也嘗試常見替代 key 名稱
        for alt_key in ('community', 'social_sentiment', 'up_down_sentiment'):
            if isinstance(event.get(alt_key), dict):
                community_sentiment = event[alt_key]
                break

    if community_sentiment and community_sentiment.get('symbol'):
        # community_sentiment 裡若有 symbol，且外層還是 UNKNOWN，補上
        if symbol == "UNKNOWN":
            symbol = community_sentiment['symbol']

    if not fng_data and not community_sentiment:
        print(f"Could not resolve fear_and_greed / community_sentiment. Event keys: {list(event.keys())}")

    return fng_data, community_sentiment, symbol


def summarize_fear_greed(fng_data):
    if not fng_data:
        return "（無 Fear & Greed Index 資料）\n"

    recent = fng_data[:MAX_FNG_POINTS]  # 已經是新到舊排序
    latest = recent[0]
    oldest = recent[-1]

    values = [d['value'] for d in recent if isinstance(d.get('value'), (int, float))]
    avg_value = round(sum(values) / len(values), 1) if values else "N/A"
    max_value = max(values) if values else "N/A"
    min_value = min(values) if values else "N/A"

    lines = []
    lines.append(f"### Fear & Greed Index（最近 {len(recent)} 筆，新到舊排序）")
    lines.append(f"最新數值: {latest.get('value')}（{latest.get('sentiment')}）  "
                 f"| 最舊數值: {oldest.get('value')}（{oldest.get('sentiment')}）")
    lines.append(f"區間平均: {avg_value} | 區間最高: {max_value} | 區間最低: {min_value}")
    lines.append("")
    lines.append("歷史明細（新到舊）:")
    for d in recent:
        lines.append(f"  t={d.get('timestamp')} value={d.get('value')} sentiment={d.get('sentiment')}")
    lines.append("")

    return "\n".join(lines)


def summarize_community_sentiment(community_sentiment):
    if not community_sentiment:
        return "（無社群情緒資料）\n"

    up_pct = community_sentiment.get('up_percentage')
    down_pct = community_sentiment.get('down_percentage')
    coingecko_id = community_sentiment.get('coingecko_id', 'N/A')

    lines = []
    lines.append("### 社群情緒（Community Sentiment，來源: CoinGecko）")
    lines.append(f"幣種 ID: {coingecko_id}")
    lines.append(f"看漲比例 (up): {up_pct}% | 看跌比例 (down): {down_pct}%")
    lines.append("")

    return "\n".join(lines)


def build_prompt(fng_data, community_sentiment, symbol):
    fng_section = summarize_fear_greed(fng_data)
    community_section = summarize_community_sentiment(community_sentiment)

    prompt = f"""請根據以下 **{symbol}** 的市場情緒資料（Fear & Greed Index 歷史走勢 + 社群看漲/看跌比例），判斷目前應該 buy（買進）、hold（觀望持有）還是 sell（賣出），並提供完整分析。

注意：這是「情緒面/反向指標」分析，請特別留意 Fear & Greed Index 的「反向操作」邏輯（極度恐懼時市場可能超賣接近底部，極度貪婪時市場可能過熱接近頂部），並與社群當下的看漲/看跌比例做交叉比對，判斷情緒是否過度一致（可能代表反轉風險）或出現分歧。

{fng_section}
{community_section}

## 請嚴格依據以下 JSON Schema 回覆：

{{
    "recommendation": "<buy/hold/sell>",
    "confidence": <0-100 的數字，表示這個建議的信心程度>,
    "sentiment_regime": "<目前情緒所處階段，例如：極度恐懼/恐懼/中性/貪婪/極度貪婪>",
    "fng_trend": "<Fear & Greed Index 近期趨勢，例如：持續惡化/築底回升/持平/快速轉貪婪>",
    "community_alignment": "<社群看漲/看跌比例與 Fear & Greed Index 是否一致，例如：情緒一致偏空/社群偏多但指數偏空，出現分歧 等>",
    "contrarian_signal": "<是否出現反向操作機會，說明理由，100字內>",
    "risk_factors": [
        "<風險因素1>",
        "<風險因素2>",
        "<風險因素3>"
    ],
    "invalidation_level": "<會讓這個情緒面判斷失效的情境，例如 Fear & Greed 指數快速跳升至某區間、社群比例反轉超過某幅度等>",
    "summary": "<200字內的中文總結，整合 Fear & Greed 趨勢與社群情緒，給出明確的操作建議與理由>"
}}

注意事項：
1. 必須回覆標準且有效的 JSON 格式。
2. 所有文字內容請使用繁體中文。
3. Fear & Greed Index 屬於情緒面指標，通常在極端值時具有「反指標」意義，請在分析中明確說明是否適用。
4. 引用數值時要用資料裡實際出現的數字，不要憑空捏造。若某一項資料缺失，請說明資料不足並主要依據現有資料分析。
5. 這是純情緒面分析，不包含技術指標或 K 線資料，請勿假設有其他資料來源。
"""
    return prompt


def call_bedrock(prompt, max_retries=5):
    request_body = {
        "anthropic_version": "bedrock-2023-05-31",
        "max_tokens": 8192,
        "temperature": 0.2,
        "system": "你是一位專業的加密貨幣市場情緒分析師，專精於 Fear & Greed Index 與社群情緒的反向指標分析。你只會輸出有效的 JSON 格式內容，絕對不包含任何額外的對話、開場白或結語。",
        "messages": [
            {
                "role": "user",
                "content": prompt
            }
        ]
    }

    RETRYABLE_ERRORS = {
        'ThrottlingException',
        'ModelTimeoutException',
        'ServiceUnavailableException',
        'InternalServerException'
    }

    for attempt in range(max_retries):
        try:
            print(f"Calling Bedrock with model: {MODEL_ID} (attempt {attempt + 1}/{max_retries})")

            response = bedrock.invoke_model(
                modelId=MODEL_ID,
                contentType="application/json",
                accept="application/json",
                body=json.dumps(request_body)
            )

            result = json.loads(response['body'].read())

            stop_reason = result.get('stop_reason', 'unknown')
            print(f"Response stop_reason: {stop_reason}")

            content = result.get('content', [])
            if content and len(content) > 0:
                return content[0].get('text', '')

            raise Exception("No content in Bedrock response")

        except ClientError as e:
            error_code = e.response['Error']['Code']
            error_message = e.response['Error'].get('Message', '')
            print(f"ClientError: {error_code} - {error_message}")

            if error_code in RETRYABLE_ERRORS and attempt < max_retries - 1:
                wait = (2 ** attempt) + random.uniform(0, 1)
                print(f"Retryable error encountered ({error_code}), retrying in {wait:.1f}s...")
                time.sleep(wait)
                continue

            raise

    raise Exception("Max retries exceeded due to Bedrock client errors")


def parse_ai_response(ai_response):
    text = ai_response.strip()

    if text.startswith('```json'):
        text = text[7:]
    elif text.startswith('```'):
        text = text[3:]

    if text.endswith('```'):
        text = text[:-3]

    text = text.strip()

    start = text.find('{')
    end = text.rfind('}') + 1

    if start != -1 and end > start:
        json_str = text[start:end]
        try:
            return json.loads(json_str)
        except json.JSONDecodeError as e:
            print(f"JSON parse error: {e}")
            print(f"Attempted to parse: {json_str[:500]}...")

    return {
        "raw_response": text[:2000],
        "parse_error": True,
        "error_message": "Failed to parse AI response as JSON."
    }


def success_response(data):
    return {
        'statusCode': 200,
        'headers': {
            'Content-Type': 'application/json; charset=utf-8',
            'Access-Control-Allow-Origin': '*',
            'Access-Control-Allow-Headers': 'Content-Type',
            'Access-Control-Allow-Methods': 'OPTIONS,POST,GET'
        },
        'body': json.dumps(data, ensure_ascii=False, indent=2)
    }


def error_response(message):
    return {
        'statusCode': 500,
        'headers': {
            'Content-Type': 'application/json; charset=utf-8',
            'Access-Control-Allow-Origin': '*',
            'Access-Control-Allow-Headers': 'Content-Type',
            'Access-Control-Allow-Methods': 'OPTIONS,POST,GET'
        },
        'body': json.dumps({
            'error': message,
            'success': False
        }, ensure_ascii=False)
    }