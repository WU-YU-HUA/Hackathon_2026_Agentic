import json
import time
import random
import boto3
from botocore.config import Config
from botocore.exceptions import ClientError

# 設定較長的 timeout（Claude Opus 回應可能較慢）
config = Config(
    read_timeout=300,
    connect_timeout=10,
    retries={'max_attempts': 3}
)

REGION = "us-west-2"
bedrock = boto3.client('bedrock-runtime', region_name=REGION, config=config)

# Claude Opus 4.5 Cross-region Inference Profile ID
MODEL_ID = "us.anthropic.claude-opus-4-5-20251101-v1:0"

# 每個 interval 最多帶入 prompt 的 K 線根數
CANDLES_PER_INTERVAL = 60

# 標準的 interval 排序（由短到長）
INTERVAL_ORDER = ["1m", "5m", "15m", "30m", "1h", "4h", "1d"]


def lambda_handler(event, context):
    """
    技術分析（多週期 K 線 + 指標）→ AI 產出 buy/hold/sell 報告
    """
    # 除錯用：印出原始 event，方便追蹤 Program A 傳來的實際結構
    try:
        print(f"[DEBUG] Raw event: {json.dumps(event, ensure_ascii=False)[:3000]}")
    except Exception:
        print(f"[DEBUG] Raw event (repr): {repr(event)[:3000]}")

    try:
        intervals_data, symbol = parse_input(event)

        if not intervals_data:
            print("[ERROR] Failed to parse any interval data from event.")
            return error_response("No interval data provided or failed to parse input.")

        print(f"Processing {len(intervals_data)} intervals for symbol: {symbol}")

        prompt = build_prompt(intervals_data, symbol)
        ai_response = call_bedrock(prompt)
        analysis = parse_ai_response(ai_response)

        analysis['metadata'] = {
            'model': MODEL_ID,
            'symbol': symbol,
            'intervals_analyzed': [d['interval'] for d in intervals_data]
        }

        return success_response(analysis)

    except Exception as e:
        print(f"Error: {str(e)}")
        import traceback
        traceback.print_exc()
        return error_response(str(e))


def parse_input(event):
    """
    解析多種傳入格式，確保穩健解包 (Unpack)
    """
    symbol = "UNKNOWN"

    # ===== 情況 1: JSON 字串 =====
    if isinstance(event, str):
        print("Input format: JSON string")
        try:
            event = json.loads(event)
        except json.JSONDecodeError:
            return [], symbol

    if not isinstance(event, dict) and not isinstance(event, list):
        print(f"Unknown input format: {type(event)}")
        return [], symbol

    # ===== 情況 2: 完整的 Lambda 回應格式 ({statusCode: 200, body: ...}) =====
    if isinstance(event, dict) and 'body' in event and ('statusCode' in event or 'headers' in event):
        print("Input format: Lambda response wrapper with body")
        body = event['body']
        if isinstance(body, str):
            try:
                body = json.loads(body)
            except json.JSONDecodeError:
                return [], symbol
        event = body

    # ===============================================================
    # 🌟 強化版: 專門接住來自 Lambda A 的 kline_data (極高容錯)
    # 支援以下所有巢狀可能性：
    #   1) {"15m": [ {candle}, {candle}, ... ]}                       -> value 直接是 list
    #   2) {"15m": {"data": [ {candle}, ... ]}}                       -> value 是 dict，內含 data
    #   3) {"15m": {"interval": "15m", "data": [ {candle}, ... ]}}    -> value 是 dict，含 interval+data
    #   4) kline_data 本身直接是 list of candles                      -> 視為單一 interval
    #   5) kline_data 本身是 list of {"interval":..., "data":[...]}   -> 已經是標準格式
    # ===============================================================
    if isinstance(event, dict) and 'kline_data' in event:
        print("Input format: kline_data from Lambda A")
        symbol = event.get('symbol', 'UNKNOWN')
        kd = event['kline_data']

        raw_list = []

        if isinstance(kd, dict):
            for k, v in kd.items():
                clean_interval = str(k).replace('_data', '').strip()
                candles = None

                if isinstance(v, list):
                    # 情況 1：value 直接是 K 線陣列
                    candles = v
                elif isinstance(v, dict):
                    # 情況 2 / 3：value 是巢狀 dict，嘗試從常見 key 取出真正的 K 線陣列
                    for candidate_key in ('data', 'candles', 'klines', 'kline'):
                        if isinstance(v.get(candidate_key), list):
                            candles = v[candidate_key]
                            break
                    # 如果巢狀 dict 裡有標示自己的 interval，優先使用它
                    if isinstance(v.get('interval'), str):
                        clean_interval = v['interval']

                if isinstance(candles, list) and candles:
                    raw_list.append({'interval': clean_interval, 'data': candles})

        elif isinstance(kd, list):
            if kd and isinstance(kd[0], dict) and 'interval' in kd[0] and 'data' in kd[0]:
                # 情況 5：已經是標準格式 list of {"interval":..., "data":[...]}
                raw_list = kd
            else:
                # 情況 4：直接是單一 interval 的 K 線陣列
                raw_list = [{'interval': event.get('interval', '15m'), 'data': kd}]

        if raw_list:
            return _normalize_interval_list(raw_list, symbol)

        # kline_data 存在但怎麼樣都解析不出東西時，印出結構方便除錯，
        # 並且「不要 return」，讓程式繼續往下嘗試其他分支（fallback）
        print(f"[WARN] 'kline_data' present but could not extract candles. "
              f"Type={type(kd)}, sample={str(kd)[:500]}")

    # ===== 情況 3: 包含 symbol 與 data (字典映射格式，例如 data: {"15m_data": [...]}) =====
    if isinstance(event, dict) and 'data' in event:
        symbol = event.get('symbol', symbol)
        data_obj = event['data']

        if isinstance(data_obj, dict):
            print("Input format: Key-Value interval map (e.g., 15m_data: [...])")
            raw_list = []
            for key, candles in data_obj.items():
                if isinstance(candles, list):
                    interval_name = key.replace('_data', '').replace('data', '').strip()
                    raw_list.append({
                        'symbol': symbol,
                        'interval': interval_name,
                        'data': candles
                    })
            if raw_list:
                return _normalize_interval_list(raw_list, symbol)

        elif isinstance(data_obj, list):
            interval_name = event.get('interval', '15m')
            return _normalize_interval_list([{'interval': interval_name, 'data': data_obj}], symbol)

    # ===== 情況 4: {"intervals": [...]} =====
    if isinstance(event, dict) and 'intervals' in event:
        print("Input format: {'intervals': [...]}")
        raw_list = event.get('intervals', [])
        symbol = event.get('symbol', symbol)
        return _normalize_interval_list(raw_list, symbol)

    # ===== 情況 5: 直接一個 list =====
    if isinstance(event, list):
        print("Input format: Direct list of interval objects")
        return _normalize_interval_list(event, symbol)

    # 🚨 如果真的完全認不得，直接把整個 event 當作單一陣列硬吃，絕不輕易報錯！
    if isinstance(event, dict):
        print("Fallback format: Treating entire dict as single interval data")
        for k, v in event.items():
            if isinstance(v, list) and v and isinstance(v[0], dict):
                return _normalize_interval_list([{'interval': k, 'data': v}], symbol)

    print(f"Could not resolve structure for event keys: {list(event.keys()) if isinstance(event, dict) else type(event)}")
    return [], symbol


def _normalize_interval_list(raw_list, default_symbol="UNKNOWN"):
    """把原始 interval 物件 list 整理成統一格式"""
    symbol = default_symbol
    intervals_data = []

    for item in raw_list:
        if not isinstance(item, dict):
            continue
        candles = item.get('data', [])
        interval_name = item.get('interval', 'unknown')
        if item.get('symbol') and item['symbol'] != 'UNKNOWN':
            symbol = item['symbol']

        intervals_data.append({
            'interval': interval_name,
            'data': candles
        })

    # 依照 1m -> 1d 排序
    def sort_key(d):
        try:
            return INTERVAL_ORDER.index(d['interval'])
        except ValueError:
            return len(INTERVAL_ORDER)

    intervals_data.sort(key=sort_key)
    return intervals_data, symbol


def summarize_interval(interval_name, candles):
    if not candles:
        return f"### {interval_name}\n（無資料）\n"

    recent = candles[-CANDLES_PER_INTERVAL:]
    latest = recent[-1]
    first = recent[0]

    price_change_pct = "N/A"
    c_latest = latest.get('close')
    c_first = first.get('close')

    if c_latest is not None and c_first is not None and c_first != 0:
        price_change_pct = f"{round((c_latest - c_first) / c_first * 100, 2)}%"

    highs = [c['high'] for c in recent if c.get('high') is not None]
    lows = [c['low'] for c in recent if c.get('low') is not None]

    lines = []
    lines.append(f"### 週期: {interval_name}（最近 {len(recent)} 根K線）")
    lines.append(f"最新收盤: {c_latest if c_latest is not None else 'N/A'}")
    lines.append(f"最新指標 -> RSI: {latest.get('rsi')}, MA7: {latest.get('ma_7')}, MA25: {latest.get('ma_25')}, "
                 f"MA99: {latest.get('ma_99')}, EMA7: {latest.get('ema_7')}, EMA25: {latest.get('ema_25')}, "
                 f"EMA99: {latest.get('ema_99')}, BB上軌: {latest.get('bb_upper')}, BB中軌: {latest.get('bb_middle')}, "
                 f"BB下軌: {latest.get('bb_lower')}")
    lines.append(f"區間變化: {price_change_pct} | 區間最高: {max(highs) if highs else 'N/A'} | "
                 f"區間最低: {min(lows) if lows else 'N/A'}")

    tail = recent[-10:]
    seq_lines = []
    for c in tail:
        seq_lines.append(
            f"  t={c.get('timestamp')} O={c.get('open')} H={c.get('high')} L={c.get('low')} "
            f"C={c.get('close')} RSI={c.get('rsi')}"
        )
    lines.append("最近 10 根明細:")
    lines.extend(seq_lines)
    lines.append("")

    return "\n".join(lines)


def build_prompt(intervals_data, symbol):
    sections = [summarize_interval(d['interval'], d['data']) for d in intervals_data]
    combined = "\n".join(sections)

    prompt = f"""請根據以下 **{symbol}** 多個時間週期（由短到長：{', '.join(d['interval'] for d in intervals_data)}）的 K 線與技術指標資料，判斷目前應該 buy（買進）、hold（觀望持有）還是 sell（賣出），並提供完整分析。

{combined}

## 請嚴格依據以下 JSON Schema 回覆：

{{
    "recommendation": "<buy/hold/sell>",
    "confidence": <0-100 的數字，表示這個建議的信心程度>,
    "timeframe_alignment": "<多週期趨勢是否一致，例如：短中長期一致看多 / 短期看空但長期看多，需觀望等>",
    "key_indicators": {{
        "trend": "<上升趨勢/下降趨勢/盤整>",
        "momentum": "<強/中/弱，依 RSI 與均線排列判斷>",
        "volatility": "<高/中/低，依布林通道寬度判斷>"
    }},
    "per_timeframe_analysis": [
        {{
            "interval": "<週期名稱>",
            "signal": "<buy/hold/sell>",
            "reasoning": "<80字內，說明這個週期為何給出此訊號，需引用實際指標數值（若指標為 null 請註明數據不足）>"
        }}
    ],
    "entry_consideration": "<如果建議 buy，適合的進場區間或條件；如果不建議，說明原因，100字內>",
    "risk_factors": [
        "<風險因素1>",
        "<風險因素2>",
        "<風險因素3>"
    ],
    "invalidation_level": "<會讓這個判斷失效的價格水位或條件，例如跌破某均線/支撐位>",
    "summary": "<200字內的中文總結，整合各週期訊號，給出明確的操作建議與理由>"
}}

注意事項：
1. 必須回覆標準且有效的 JSON 格式。
2. 所有文字內容請使用繁體中文。
3. 綜合判斷時，長週期（如 4h、1d）的趨勢權重應高於短週期（如 1m、5m）。
4. 引用指標數值時要用資料裡實際出現的數字，不要憑空捏造。若指標全為 null，請主要依據價格型態與高低點變化分析。
"""
    return prompt


def call_bedrock(prompt, max_retries=5):
    request_body = {
        "anthropic_version": "bedrock-2023-05-31",
        "max_tokens": 8192,
        "temperature": 0.2,
        "system": "你是一位專業的加密貨幣技術分析師。你只會輸出有效的 JSON 格式內容，絕對不包含任何額外的對話、開場白或結語。",
        "messages": [
            {
                "role": "user",
                "content": prompt
            }
        ]
    }

    RETRYABLE_ERRORS = {
        'ThrottlingException',
        'ModelTimeoutException',
        'ServiceUnavailableException',
        'InternalServerException'
    }

    for attempt in range(max_retries):
        try:
            print(f"Calling Bedrock with model: {MODEL_ID} (attempt {attempt + 1}/{max_retries})")

            response = bedrock.invoke_model(
                modelId=MODEL_ID,
                contentType="application/json",
                accept="application/json",
                body=json.dumps(request_body)
            )

            result = json.loads(response['body'].read())

            stop_reason = result.get('stop_reason', 'unknown')
            print(f"Response stop_reason: {stop_reason}")

            content = result.get('content', [])
            if content and len(content) > 0:
                return content[0].get('text', '')

            raise Exception("No content in Bedrock response")

        except ClientError as e:
            error_code = e.response['Error']['Code']
            error_message = e.response['Error'].get('Message', '')
            print(f"ClientError: {error_code} - {error_message}")

            if error_code in RETRYABLE_ERRORS and attempt < max_retries - 1:
                wait = (2 ** attempt) + random.uniform(0, 1)
                print(f"Retryable error encountered ({error_code}), retrying in {wait:.1f}s...")
                time.sleep(wait)
                continue

            raise

    raise Exception("Max retries exceeded due to Bedrock client errors")


def parse_ai_response(ai_response):
    text = ai_response.strip()

    if text.startswith('```json'):
        text = text[7:]
    elif text.startswith('```'):
        text = text[3:]

    if text.endswith('```'):
        text = text[:-3]

    text = text.strip()

    start = text.find('{')
    end = text.rfind('}') + 1

    if start != -1 and end > start:
        json_str = text[start:end]
        try:
            return json.loads(json_str)
        except json.JSONDecodeError as e:
            print(f"JSON parse error: {e}")
            print(f"Attempted to parse: {json_str[:500]}...")

    return {
        "raw_response": text[:2000],
        "parse_error": True,
        "error_message": "Failed to parse AI response as JSON."
    }


def success_response(data):
    return {
        'statusCode': 200,
        'headers': {
            'Content-Type': 'application/json; charset=utf-8',
            'Access-Control-Allow-Origin': '*',
            'Access-Control-Allow-Headers': 'Content-Type',
            'Access-Control-Allow-Methods': 'OPTIONS,POST,GET'
        },
        'body': json.dumps(data, ensure_ascii=False, indent=2)
    }


def error_response(message):
    return {
        'statusCode': 500,
        'headers': {
            'Content-Type': 'application/json; charset=utf-8',
            'Access-Control-Allow-Origin': '*',
            'Access-Control-Allow-Headers': 'Content-Type',
            'Access-Control-Allow-Methods': 'OPTIONS,POST,GET'
        },
        'body': json.dumps({
            'error': message,
            'success': False
        }, ensure_ascii=False)
    }