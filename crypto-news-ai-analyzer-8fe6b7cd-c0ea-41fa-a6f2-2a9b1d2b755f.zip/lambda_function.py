import json
import time
import random
import boto3
from botocore.config import Config
from botocore.exceptions import ClientError

# 設定較長的 timeout（Claude Opus 回應可能較慢）
config = Config(
    read_timeout=300,
    connect_timeout=10,
    retries={'max_attempts': 3}
)

REGION = "us-west-2"
bedrock = boto3.client('bedrock-runtime', region_name=REGION, config=config)
comprehend = boto3.client('comprehend', region_name=REGION)

# Claude Opus 4.5 Cross-region Inference Profile ID
MODEL_ID = "us.anthropic.claude-opus-4-5-20251101-v1:0"

# tag -> 相關關鍵詞別名對照（用來判斷 Comprehend 偵測到的 entity 是否命中目標幣種）
TAG_ALIASES = {
    'bitcoin': ['bitcoin', 'btc'],
    'btc': ['bitcoin', 'btc'],
    'ethereum': ['ethereum', 'eth', 'ether'],
    'eth': ['ethereum', 'eth', 'ether'],
}

# Comprehend batch_detect_entities 一次最多吃 25 筆文件
COMPREHEND_BATCH_SIZE = 25

# entity 分數門檻，低於此分數不列入「相關」判斷
ENTITY_SCORE_THRESHOLD = 0.5


def lambda_handler(event, context):
    """
    新聞面分析（crypto-news 的輸出 → Comprehend 相關性過濾 → AI 產出情緒/事件分析報告）
    """
    try:
        print(f"[DEBUG] Raw event: {json.dumps(event, ensure_ascii=False)[:3000]}")
    except Exception:
        print(f"[DEBUG] Raw event (repr): {repr(event)[:3000]}")

    try:
        tag, news_list = parse_input(event)

        if not news_list:
            print("[ERROR] Failed to parse any news data from event.")
            return error_response("No news data provided or failed to parse input.")

        original_count = len(news_list)
        print(f"Processing {original_count} news items for tag: {tag}")

        # ===== Comprehend 相關性過濾 =====
        filtered_news, filtered_out = filter_relevant_news(news_list, tag)
        print(f"Comprehend filtering: {len(filtered_news)}/{original_count} 則保留 "
              f"（過濾掉 {len(filtered_out)} 則不相關新聞）")

        if filtered_out:
            print("[DEBUG] 被過濾掉的新聞標題: " +
                  "; ".join(item.get('title', 'N/A') for item in filtered_out[:10]))

        # 保護機制：如果 Comprehend 把所有新聞都濾掉了（例如 tag 拼寫特殊、Comprehend 辨識不到），
        # 就退回用原始新聞清單，避免整個分析因為過濾過頭而失敗
        news_to_analyze = filtered_news if filtered_news else news_list
        if not filtered_news:
            print("[WARN] Comprehend 過濾後沒有任何新聞保留，改用原始新聞清單以避免分析失敗")

        prompt = build_prompt(tag, news_to_analyze)
        ai_response = call_bedrock(prompt)
        analysis = parse_ai_response(ai_response)

        analysis['metadata'] = {
            'model': MODEL_ID,
            'tag': tag,
            'news_count': original_count,
            'analyzed_count': len(news_to_analyze),
            'filtered_out_count': len(filtered_out)
        }

        return success_response(analysis)

    except Exception as e:
        print(f"Error: {str(e)}")
        import traceback
        traceback.print_exc()
        return error_response(str(e))


def parse_input(event):
    """
    解析多種傳入格式，確保穩健解包 (Unpack)
    回傳: (tag: str, news_list: list)
    """
    tag = "UNKNOWN"

    # ===== 情況 1: JSON 字串 =====
    if isinstance(event, str):
        print("Input format: JSON string")
        try:
            event = json.loads(event)
        except json.JSONDecodeError:
            return tag, []

    if not isinstance(event, dict):
        print(f"Unknown input format: {type(event)}")
        return tag, []

    # ===== 情況 2: 完整的 Lambda 回應格式 ({statusCode: 200, body: ...}) =====
    if 'body' in event and ('statusCode' in event or 'headers' in event):
        print("Input format: Lambda response wrapper with body")
        body = event['body']
        if isinstance(body, str):
            try:
                body = json.loads(body)
            except json.JSONDecodeError:
                return tag, []
        event = body

    if not isinstance(event, dict):
        return tag, []

    # ===== 標準格式: {"tag": "bitcoin", "count": 30, "news": [...]} =====
    tag = event.get('tag', tag)
    news_list = event.get('news', [])

    if not isinstance(news_list, list):
        # 容錯：也支援 news_data 這個 key 名稱
        news_list = event.get('news_data', [])

    news_list = [item for item in news_list if isinstance(item, dict)]

    if not news_list:
        print(f"Could not resolve news list. Event keys: {list(event.keys())}")

    return tag, news_list


def filter_relevant_news(news_list, tag):
    """
    用 Amazon Comprehend 的 Entity Recognition 過濾掉跟 tag 相關性不足的新聞。
    對每則新聞的 title+context 做實體辨識，檢查是否偵測到目標幣種相關的 entity，
    且信心分數達到門檻。

    回傳: (kept_list, filtered_out_list)
    """
    if not news_list:
        return [], []

    aliases = TAG_ALIASES.get(tag.lower(), [tag.lower()])

    kept = []
    filtered_out = []

    # Comprehend batch_detect_entities 一次最多 25 筆，這裡分批處理
    for batch_start in range(0, len(news_list), COMPREHEND_BATCH_SIZE):
        batch = news_list[batch_start:batch_start + COMPREHEND_BATCH_SIZE]
        text_list = [
            f"{item.get('title', '')}. {item.get('context', item.get('summary', ''))}"[:5000]
            for item in batch
        ]

        try:
            response = comprehend.batch_detect_entities(
                TextList=text_list,
                LanguageCode='en'
            )
        except ClientError as e:
            print(f"[WARN] Comprehend batch_detect_entities 呼叫失敗: {e}. "
                  f"這批新聞將直接保留，不做過濾。")
            kept.extend(batch)
            continue

        result_list = response.get('ResultList', [])
        error_list = response.get('ErrorList', [])

        # 建立 index -> entities 的對照（ResultList 的 Index 對應原始 text_list 的順序）
        entities_by_index = {r['Index']: r.get('Entities', []) for r in result_list}
        error_indices = {e['Index'] for e in error_list}

        for i, item in enumerate(batch):
            if i in error_indices:
                # Comprehend 對這筆處理失敗，保守起見保留原新聞
                print(f"[WARN] Comprehend 處理失敗，保留原新聞: {item.get('title', 'N/A')}")
                kept.append(item)
                continue

            entities = entities_by_index.get(i, [])
            is_relevant = any(
                any(alias in e.get('Text', '').lower() for alias in aliases)
                and e.get('Score', 0) >= ENTITY_SCORE_THRESHOLD
                for e in entities
            )

            if is_relevant:
                kept.append(item)
            else:
                filtered_out.append(item)

    return kept, filtered_out


def build_prompt(tag, news_list):
    news_lines = []
    for i, item in enumerate(news_list, 1):
        title = item.get('title', 'N/A')
        context = item.get('context', item.get('summary', 'N/A'))
        news_lines.append(f"{i}. 標題: {title}\n   內容: {context}")

    news_section = "\n".join(news_lines)

    prompt = f"""請根據以下 **{tag}** 相關的新聞資料（共 {len(news_list)} 則，已經過相關性過濾），
進行新聞面情緒分析，判斷這些新聞對市場短中期走勢的影響。

## 新聞列表：

{news_section}

## 請嚴格依據以下 JSON Schema 回覆：

{{
    "overall_sentiment": {{
        "score": <0-100 的數字，分數越高代表整體新聞情緒越正面>,
        "label": "<偏正面/中性/偏負面，需對應 score 區間>",
        "confidence": <0-100 的數字，表示這個情緒判斷的信心程度>
    }},
    "news_breakdown": {{
        "total": {len(news_list)},
        "positive": <正面新聞則數>,
        "negative": <負面新聞則數>,
        "neutral": <中性新聞則數>
    }},
    "key_events": [
        {{
            "title": "<新聞標題，需完全引用原標題>",
            "impact": "<positive/negative/neutral>",
            "importance": "<高/中/低>",
            "summary": "<80字內的中文摘要與影響說明>"
        }}
    ],
    "market_impact": {{
        "short_term": "<看漲/看跌/中性>",
        "short_term_reasoning": "<150字內，說明短期影響判斷理由>",
        "medium_term": "<看漲/看跌/中性>",
        "medium_term_reasoning": "<150字內，說明中期影響判斷理由>"
    }},
    "risk_factors": [
        "<風險因素1>",
        "<風險因素2>",
        "<風險因素3>"
    ],
    "opportunities": [
        "<機會因素1>",
        "<機會因素2>"
    ],
    "summary": "<200字內的中文總結，整合所有新聞給出整體市場情緒判斷>"
}}

注意事項：
1. 必須回覆標準且有效的 JSON 格式。
2. 所有文字內容請使用繁體中文（key_events 的 title 除外，需保留原文標題）。
3. key_events 只挑選最重要的 3-6 則，不需要每則新聞都列入。
4. news_breakdown 的 positive+negative+neutral 加總必須等於 total。
5. 判斷時要基於新聞列表裡實際出現的內容，不要憑空捏造未提及的事件。
"""
    return prompt


def call_bedrock(prompt, max_retries=5):
    request_body = {
        "anthropic_version": "bedrock-2023-05-31",
        "max_tokens": 8192,
        "temperature": 0.2,
        "system": "你是一位專業的加密貨幣新聞分析師，專精於從新聞事件判斷市場情緒與短中期價格影響。"
                  "你只會輸出有效的 JSON 格式內容，絕對不包含任何額外的對話、開場白或結語。",
        "messages": [
            {
                "role": "user",
                "content": prompt
            }
        ]
    }

    RETRYABLE_ERRORS = {
        'ThrottlingException',
        'ModelTimeoutException',
        'ServiceUnavailableException',
        'InternalServerException'
    }

    for attempt in range(max_retries):
        try:
            print(f"Calling Bedrock with model: {MODEL_ID} (attempt {attempt + 1}/{max_retries})")

            response = bedrock.invoke_model(
                modelId=MODEL_ID,
                contentType="application/json",
                accept="application/json",
                body=json.dumps(request_body)
            )

            result = json.loads(response['body'].read())

            stop_reason = result.get('stop_reason', 'unknown')
            print(f"Response stop_reason: {stop_reason}")

            content = result.get('content', [])
            if content and len(content) > 0:
                return content[0].get('text', '')

            raise Exception("No content in Bedrock response")

        except ClientError as e:
            error_code = e.response['Error']['Code']
            error_message = e.response['Error'].get('Message', '')
            print(f"ClientError: {error_code} - {error_message}")

            if error_code in RETRYABLE_ERRORS and attempt < max_retries - 1:
                wait = (2 ** attempt) + random.uniform(0, 1)
                print(f"Retryable error encountered ({error_code}), retrying in {wait:.1f}s...")
                time.sleep(wait)
                continue

            raise

    raise Exception("Max retries exceeded due to Bedrock client errors")


def parse_ai_response(ai_response):
    text = ai_response.strip()

    if text.startswith('```json'):
        text = text[7:]
    elif text.startswith('```'):
        text = text[3:]

    if text.endswith('```'):
        text = text[:-3]

    text = text.strip()

    start = text.find('{')
    end = text.rfind('}') + 1

    if start != -1 and end > start:
        json_str = text[start:end]
        try:
            return json.loads(json_str)
        except json.JSONDecodeError as e:
            print(f"JSON parse error: {e}")
            print(f"Attempted to parse: {json_str[:500]}...")

    return {
        "raw_response": text[:2000],
        "parse_error": True,
        "error_message": "Failed to parse AI response as JSON."
    }


def success_response(data):
    return {
        'statusCode': 200,
        'headers': {
            'Content-Type': 'application/json; charset=utf-8',
            'Access-Control-Allow-Origin': '*',
            'Access-Control-Allow-Headers': 'Content-Type',
            'Access-Control-Allow-Methods': 'OPTIONS,POST,GET'
        },
        'body': json.dumps(data, ensure_ascii=False, indent=2)
    }


def error_response(message):
    return {
        'statusCode': 500,
        'headers': {
            'Content-Type': 'application/json; charset=utf-8',
            'Access-Control-Allow-Origin': '*',
            'Access-Control-Allow-Headers': 'Content-Type',
            'Access-Control-Allow-Methods': 'OPTIONS,POST,GET'
        },
        'body': json.dumps({
            'error': message,
            'success': False
        }, ensure_ascii=False)
    }