import json
import time
import random
import boto3
from botocore.config import Config
from botocore.exceptions import ClientError

# 設定較長的 timeout（Claude Opus 回應可能較慢）
config = Config(
    read_timeout=300,
    connect_timeout=10,
    retries={'max_attempts': 3}
)

REGION = "us-west-2"
bedrock = boto3.client('bedrock-runtime', region_name=REGION, config=config)

# Claude Opus 4.5 Cross-region Inference Profile ID
MODEL_ID = "us.anthropic.claude-opus-4-5-20251101-v1:0"

DEFAULT_RISK_LEVEL = 5


def lambda_handler(event, context):
    """
    彙整服務 (Lambda D)：
    接收 kline(技術面) / social(情緒面) / news(新聞面) 三份 report + risk_level
    → AI 產出最終 buy/hold/sell 報告 + 依風險等級客製化的操作策略
    """
    try:
        print(f"[DEBUG] Raw event: {json.dumps(event, ensure_ascii=False)[:3000]}")
    except Exception:
        print(f"[DEBUG] Raw event (repr): {repr(event)[:3000]}")

    try:
        symbol, risk_level, technical_report, social_report, news_report = parse_input(event)

        if not any([technical_report, social_report, news_report]):
            print("[ERROR] Failed to parse any of the three reports from event.")
            return error_response("No technical/social/news report provided or failed to parse input.")

        print(f"Processing summary for symbol: {symbol}, risk_level: {risk_level} "
              f"(technical: {bool(technical_report)}, social: {bool(social_report)}, news: {bool(news_report)})")

        prompt = build_prompt(symbol, risk_level, technical_report, social_report, news_report)
        ai_response = call_bedrock(prompt)
        analysis = parse_ai_response(ai_response)

        analysis['metadata'] = {
            'model': MODEL_ID,
            'symbol': symbol,
            'risk_level': risk_level,
            'reports_used': {
                'technical': bool(technical_report),
                'social': bool(social_report),
                'news': bool(news_report)
            }
        }

        return success_response(analysis)

    except Exception as e:
        print(f"Error: {str(e)}")
        import traceback
        traceback.print_exc()
        return error_response(str(e))


def parse_input(event):
    """
    解析多種傳入格式，確保穩健解包 (Unpack)
    回傳: (symbol, risk_level, technical_report, social_report, news_report)
    """
    symbol = "UNKNOWN"
    risk_level = DEFAULT_RISK_LEVEL
    technical_report = None
    social_report = None
    news_report = None

    # ===== 情況 1: JSON 字串 =====
    if isinstance(event, str):
        print("Input format: JSON string")
        try:
            event = json.loads(event)
        except json.JSONDecodeError:
            return symbol, risk_level, technical_report, social_report, news_report

    if not isinstance(event, dict):
        print(f"Unknown input format: {type(event)}")
        return symbol, risk_level, technical_report, social_report, news_report

    # ===== 情況 2: 完整的 Lambda 回應格式 ({statusCode: 200, body: ...}) =====
    if 'body' in event and ('statusCode' in event or 'headers' in event):
        print("Input format: Lambda response wrapper with body")
        body = event['body']
        if isinstance(body, str):
            try:
                body = json.loads(body)
            except json.JSONDecodeError:
                return symbol, risk_level, technical_report, social_report, news_report
        event = body

    if not isinstance(event, dict):
        return symbol, risk_level, technical_report, social_report, news_report

    symbol = event.get('symbol', symbol)

    # ===== risk_level: 容錯處理，並夾在 1~10 之間 =====
    raw_risk = event.get('risk_level', DEFAULT_RISK_LEVEL)
    try:
        risk_level = int(raw_risk)
    except (TypeError, ValueError):
        print(f"[WARN] risk_level 無法轉為整數 (收到: {raw_risk})，使用預設值 {DEFAULT_RISK_LEVEL}")
        risk_level = DEFAULT_RISK_LEVEL
    risk_level = max(1, min(10, risk_level))

    # ===== 三份 report：支援直接放在頂層，或包在 'reports' 底下 =====
    container = event
    if isinstance(event.get('reports'), dict):
        container = event['reports']

    # 支援多種常見 key 命名，盡量容錯
    technical_report = (container.get('technical_report') or container.get('kline_report')
                         or container.get('technical_analysis'))
    social_report = (container.get('social_report') or container.get('sentiment_report')
                      or container.get('social_analysis'))
    news_report = (container.get('news_report') or container.get('news_analysis'))

    # 若三份都拿不到，且 container 本身看起來就是單一 report（含 recommendation 或 overall_sentiment），
    # 至少不要整個放棄，印出警告方便除錯
    if not any([technical_report, social_report, news_report]):
        print(f"[WARN] 三份 report 都沒抓到。container keys: {list(container.keys())}")

    return symbol, risk_level, technical_report, social_report, news_report


def get_risk_profile(risk_level):
    """依 risk_level 回傳風險級距標籤與操作準則（給 prompt 使用）"""
    if risk_level <= 3:
        return {
            'label': '保守',
            'guideline': (
                "優先建議 hold，只有三份 report 高度一致看多時才建議 buy；"
                "止損設緊（約 3-5%），建議倉位佔總資產 5-15%；分批策略應保守，分多批小量進場。"
            )
        }
    elif risk_level <= 7:
        return {
            'label': '中性',
            'guideline': (
                "以技術面為主要依據，情緒面與新聞面作為輔助確認；"
                "止損適中（約 5-8%），建議倉位佔總資產 15-30%；可分 2-3 批進出場。"
            )
        }
    else:
        return {
            'label': '積極',
            'guideline': (
                "容忍度較高，技術面出現初步訊號即可考慮進場；"
                "止損可放寬（約 8-12%），建議倉位佔總資產 30-50%；可接受較快的加碼或減倉節奏。"
            )
        }


def summarize_technical_report(report):
    if not report:
        return "（無技術面分析資料）\n"

    lines = []
    lines.append("### 技術面分析（kline analyzer）")
    lines.append(f"建議: {report.get('recommendation', 'N/A')} | 信心度: {report.get('confidence', 'N/A')}")
    lines.append(f"多週期趨勢一致性: {report.get('timeframe_alignment', 'N/A')}")

    ki = report.get('key_indicators', {})
    if ki:
        lines.append(f"趨勢: {ki.get('trend', 'N/A')} | 動能: {ki.get('momentum', 'N/A')} | "
                     f"波動度: {ki.get('volatility', 'N/A')}")

    lines.append(f"進場考量: {report.get('entry_consideration', 'N/A')}")
    lines.append(f"失效條件: {report.get('invalidation_level', 'N/A')}")

    risk_factors = report.get('risk_factors', [])
    if risk_factors:
        lines.append("風險因素: " + "; ".join(risk_factors))

    lines.append(f"總結: {report.get('summary', 'N/A')}")
    lines.append("")
    return "\n".join(lines)


def summarize_social_report(report):
    if not report:
        return "（無情緒面分析資料）\n"

    lines = []
    lines.append("### 情緒面分析（social/fear&greed analyzer）")
    lines.append(f"建議: {report.get('recommendation', 'N/A')} | 信心度: {report.get('confidence', 'N/A')}")
    lines.append(f"情緒階段: {report.get('sentiment_regime', 'N/A')}")
    lines.append(f"Fear & Greed 趨勢: {report.get('fng_trend', 'N/A')}")
    lines.append(f"社群一致性: {report.get('community_alignment', 'N/A')}")
    lines.append(f"反指標訊號: {report.get('contrarian_signal', 'N/A')}")
    lines.append(f"失效條件: {report.get('invalidation_level', 'N/A')}")

    risk_factors = report.get('risk_factors', [])
    if risk_factors:
        lines.append("風險因素: " + "; ".join(risk_factors))

    lines.append(f"總結: {report.get('summary', 'N/A')}")
    lines.append("")
    return "\n".join(lines)


def summarize_news_report(report):
    if not report:
        return "（無新聞面分析資料）\n"

    lines = []
    lines.append("### 新聞面分析（news analyzer）")

    os_ = report.get('overall_sentiment', {})
    lines.append(f"整體情緒: {os_.get('label', 'N/A')} (分數: {os_.get('score', 'N/A')}, "
                 f"信心度: {os_.get('confidence', 'N/A')})")

    nb = report.get('news_breakdown', {})
    if nb:
        lines.append(f"新聞分佈: 共 {nb.get('total', 'N/A')} 則, "
                     f"正面 {nb.get('positive', 'N/A')} / 負面 {nb.get('negative', 'N/A')} / "
                     f"中性 {nb.get('neutral', 'N/A')}")

    mi = report.get('market_impact', {})
    if mi:
        lines.append(f"短期影響: {mi.get('short_term', 'N/A')} — {mi.get('short_term_reasoning', 'N/A')}")
        lines.append(f"中期影響: {mi.get('medium_term', 'N/A')} — {mi.get('medium_term_reasoning', 'N/A')}")

    key_events = report.get('key_events', [])
    if key_events:
        lines.append("重點事件:")
        for ev in key_events[:5]:
            lines.append(f"  - [{ev.get('importance', 'N/A')}/{ev.get('impact', 'N/A')}] "
                         f"{ev.get('title', 'N/A')}: {ev.get('summary', 'N/A')}")

    risk_factors = report.get('risk_factors', [])
    if risk_factors:
        lines.append("風險因素: " + "; ".join(risk_factors))

    opportunities = report.get('opportunities', [])
    if opportunities:
        lines.append("機會因素: " + "; ".join(opportunities))

    lines.append(f"總結: {report.get('summary', 'N/A')}")
    lines.append("")
    return "\n".join(lines)


def build_prompt(symbol, risk_level, technical_report, social_report, news_report):
    technical_section = summarize_technical_report(technical_report)
    social_section = summarize_social_report(social_report)
    news_section = summarize_news_report(news_report)

    risk_profile = get_risk_profile(risk_level)

    prompt = f"""【系統最高級別強制指令】
你是一個純粹的數據分析輸出引擎。
絕對禁止輸出任何人類問候語、自我介紹、或前言結語！
禁止出現：「尊敬的投資者」、「您好」、「作為一位...」、「我將為您...」等廢話。
你的回覆必須、立刻、直接依照下方要求的 JSON 格式輸出，不包含任何額外文字。

【使用者背景】
- 選擇幣種：{symbol}
- 風險偏好：{risk_level} (1-10，屬於「{risk_profile['label']}」等級，請務必嚴格根據此風險等級調整你的資金分配與止損建議)

【風險等級操作準則（僅供你判斷 personalized_strategy 時參考，market_assessment 不受此影響）】
{risk_profile['guideline']}

【三份獨立分析報告】
以下三份報告，分別來自技術面、情緒面、新聞面三支獨立的 AI 分析引擎：

{technical_section}
{social_section}
{news_section}

## 你的任務分為兩層，請嚴格區分：

**第一層：市場客觀評估（market_assessment）**
綜合以上三份報告，判斷市場目前客觀上偏多、偏空還是中性。這一層**不受使用者風險等級影響**，任何風險等級的使用者看到的都應該是同一個市場判斷。若三份報告之間出現衝突（例如技術面看多但新聞面偏空），必須明確指出衝突並說明如何權衡、以何者為主。

**第二層：個人化操作策略（personalized_strategy）**
基於第一層的市場判斷，結合使用者的風險等級，給出具體可執行的操作建議（倉位、進出場價位、止盈止損、分批節奏）。這一層會因風險等級不同而給出不同答案。

## 請嚴格依據以下 JSON Schema 回覆：

{{
    "market_assessment": {{
        "recommendation": "<buy/hold/sell，純市場面客觀判斷，不受風險等級影響>",
        "confidence": <0-100 的數字>,
        "signal_alignment": "<三份報告是否一致；若衝突，明確指出衝突點與權衡方式，150字內>",
        "technical_summary": "<技術面結論摘要，80字內>",
        "sentiment_summary": "<情緒面結論摘要，80字內>",
        "news_summary": "<新聞面結論摘要，80字內>"
    }},
    "personalized_strategy": {{
        "risk_level": {risk_level},
        "risk_profile_label": "{risk_profile['label']}",
        "position_size_pct": "<建議佔總資產百分比，依風險等級調整>",
        "entry_range": "<建倉區間，請給出具體價格範圍>",
        "take_profit": "<止盈目標，請給出具體價格>",
        "stop_loss": "<止損防守，請給出具體價格>",
        "scaling_strategy": "<分批進出場時機，需針對此風險等級說明加碼或減倉條件>"
    }},
    "risk_factors": [
        "<綜合三份報告後最需留意的風險因素1>",
        "<風險因素2>",
        "<風險因素3>"
    ],
    "report_markdown": "<完整 Markdown 格式報告全文字串，內容需包含以下三個區塊，格式規則見下方>"
}}

## report_markdown 欄位內部的格式規則（務必嚴格遵守，這是給人類直接閱讀的報告）：

report_markdown 這個欄位的內容本身要是一個完整的 Markdown 文件，結構如下：

### 1. 市場趨勢總結
(綜合評估目前的多空力道與情緒面狀況，整合三份報告)

### 2. 三維度分析摘要
* **技術面**：...
* **情緒面**：...
* **新聞面**：...

### 3. 具體操作建議表（基於風險等級 {risk_level}）
請務必連同「表頭」與「分隔線」完整輸出以下 Markdown 表格：

| 決策指標 | 具體建議數值與行動 |
| :--- | :--- |
| **建議方向** | (填寫：買入 / 做空 / 觀望) |
| **資金分配** | (建議佔總資產 %) |
| **建倉區間** | (請給出具體價格) |
| **止盈目標** | (請給出具體價格) |
| **止損防守** | (請給出具體價格) |
| **分批時機** | (針對風險等級 {risk_level} 的加碼或減倉條件) |

注意事項：
1. 必須回覆標準且有效的 JSON 格式（外層是 JSON，report_markdown 是這個 JSON 裡的一個字串欄位，內含 Markdown 語法）。
2. 所有文字內容請使用繁體中文。
3. market_assessment 與 personalized_strategy 的欄位內容要與 report_markdown 裡描述的完全一致，不能互相矛盾。
4. 引用數值時要用資料裡實際出現的數字，不要憑空捏造。
"""
    return prompt


def call_bedrock(prompt, max_retries=5):
    request_body = {
        "anthropic_version": "bedrock-2023-05-31",
        "max_tokens": 8192,
        "temperature": 0.2,
        "system": "你是一位專業的加密貨幣投資組合策略師，專精於整合技術面、情緒面、新聞面三種獨立分析，"
                  "並依照使用者風險承受度給出可執行的操作建議。你只會輸出有效的 JSON 格式內容，"
                  "絕對不包含任何額外的對話、開場白或結語。",
        "messages": [
            {
                "role": "user",
                "content": prompt
            }
        ]
    }

    RETRYABLE_ERRORS = {
        'ThrottlingException',
        'ModelTimeoutException',
        'ServiceUnavailableException',
        'InternalServerException'
    }

    for attempt in range(max_retries):
        try:
            print(f"Calling Bedrock with model: {MODEL_ID} (attempt {attempt + 1}/{max_retries})")

            response = bedrock.invoke_model(
                modelId=MODEL_ID,
                contentType="application/json",
                accept="application/json",
                body=json.dumps(request_body)
            )

            result = json.loads(response['body'].read())

            stop_reason = result.get('stop_reason', 'unknown')
            print(f"Response stop_reason: {stop_reason}")

            content = result.get('content', [])
            if content and len(content) > 0:
                return content[0].get('text', '')

            raise Exception("No content in Bedrock response")

        except ClientError as e:
            error_code = e.response['Error']['Code']
            error_message = e.response['Error'].get('Message', '')
            print(f"ClientError: {error_code} - {error_message}")

            if error_code in RETRYABLE_ERRORS and attempt < max_retries - 1:
                wait = (2 ** attempt) + random.uniform(0, 1)
                print(f"Retryable error encountered ({error_code}), retrying in {wait:.1f}s...")
                time.sleep(wait)
                continue

            raise

    raise Exception("Max retries exceeded due to Bedrock client errors")


def parse_ai_response(ai_response):
    text = ai_response.strip()

    if text.startswith('```json'):
        text = text[7:]
    elif text.startswith('```'):
        text = text[3:]

    if text.endswith('```'):
        text = text[:-3]

    text = text.strip()

    start = text.find('{')
    end = text.rfind('}') + 1

    if start != -1 and end > start:
        json_str = text[start:end]
        try:
            return json.loads(json_str)
        except json.JSONDecodeError as e:
            print(f"JSON parse error: {e}")
            print(f"Attempted to parse: {json_str[:500]}...")

    return {
        "raw_response": text[:2000],
        "parse_error": True,
        "error_message": "Failed to parse AI response as JSON."
    }


def success_response(data):
    return {
        'statusCode': 200,
        'headers': {
            'Content-Type': 'application/json; charset=utf-8',
            'Access-Control-Allow-Origin': '*',
            'Access-Control-Allow-Headers': 'Content-Type',
            'Access-Control-Allow-Methods': 'OPTIONS,POST,GET'
        },
        'body': json.dumps(data, ensure_ascii=False, indent=2)
    }


def error_response(message):
    return {
        'statusCode': 500,
        'headers': {
            'Content-Type': 'application/json; charset=utf-8',
            'Access-Control-Allow-Origin': '*',
            'Access-Control-Allow-Headers': 'Content-Type',
            'Access-Control-Allow-Methods': 'OPTIONS,POST,GET'
        },
        'body': json.dumps({
            'error': message,
            'success': False
        }, ensure_ascii=False)
    }